import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  answers,
  courses,
  oralSessions,
  questionProgress,
  questions,
} from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { evaluateAnswer } from "@/lib/ai";
import { sm2Update } from "@/lib/sm2";

export const runtime = "nodejs";
export const maxDuration = 30;

// Évalue une réponse orale : score /100, verdict, points manquants,
// puis met à jour la répétition espacée (SM-2 simplifié).
export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  let body: {
    oralSessionId?: string;
    questionId?: string;
    transcript?: string;
    responseMode?: "oral" | "written";
  } = {};
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid_body" }, { status: 400 });
  }

  const { oralSessionId, questionId } = body;
  const transcript = (body.transcript ?? "").slice(0, 4000); // plafond coût IA
  if (!oralSessionId || !questionId) {
    return NextResponse.json({ error: "invalid_body" }, { status: 400 });
  }

  const sessionRows = await db
    .select({ id: oralSessions.id })
    .from(oralSessions)
    .where(and(eq(oralSessions.id, oralSessionId), eq(oralSessions.userId, user.id)))
    .limit(1);
  if (!sessionRows[0]) return NextResponse.json({ error: "not_found" }, { status: 404 });

  const questionRows = await db
    .select({
      id: questions.id,
      prompt: questions.prompt,
      modelAnswer: questions.modelAnswer,
      keyPoints: questions.keyPoints,
      courseTitle: courses.title,
    })
    .from(questions)
    .innerJoin(courses, eq(questions.courseId, courses.id))
    .where(eq(questions.id, questionId))
    .limit(1);
  const question = questionRows[0];
  if (!question) return NextResponse.json({ error: "not_found" }, { status: 404 });

  const evaluation = await evaluateAnswer({
    question: question.prompt,
    modelAnswer: question.modelAnswer,
    keyPoints: question.keyPoints,
    transcript,
    courseTitle: question.courseTitle,
    lang: user.locale === "en" ? "en" : "fr",
  });

  // --- SM-2 ---
  const existing = await db
    .select()
    .from(questionProgress)
    .where(and(eq(questionProgress.userId, user.id), eq(questionProgress.questionId, questionId)))
    .limit(1);
  const prev = existing[0];
  const updated = sm2Update(prev ?? null, evaluation.score);
  if (prev) {
    await db
      .update(questionProgress)
      .set({
        easiness: updated.easiness,
        intervalDays: updated.intervalDays,
        repetitions: updated.repetitions,
        lapses: updated.lapses,
        lastScore: evaluation.score,
        nextDueAt: updated.nextDueAt,
        updatedAt: new Date(),
      })
      .where(eq(questionProgress.id, prev.id));
  } else {
    await db.insert(questionProgress).values({
      userId: user.id,
      questionId,
      easiness: updated.easiness,
      intervalDays: updated.intervalDays,
      repetitions: updated.repetitions,
      lapses: updated.lapses,
      lastScore: evaluation.score,
      nextDueAt: updated.nextDueAt,
    });
  }

  await db.insert(answers).values({
    oralSessionId,
    questionId,
    transcript,
    responseMode: body.responseMode === "written" ? "written" : "oral",
    score: evaluation.score,
    verdict: evaluation.verdict,
    feedback: evaluation.feedback,
    missingPoints: evaluation.missing,
  });

  // Met à jour les agrégats de la session
  const scores = await db
    .select({ score: answers.score })
    .from(answers)
    .where(eq(answers.oralSessionId, oralSessionId));
  const avgScore = Math.round(scores.reduce((a, s) => a + s.score, 0) / scores.length);
  await db
    .update(oralSessions)
    .set({ avgScore, answeredCount: scores.length })
    .where(eq(oralSessions.id, oralSessionId));

  return NextResponse.json({ ...evaluation, modelAnswer: question.modelAnswer });
}
