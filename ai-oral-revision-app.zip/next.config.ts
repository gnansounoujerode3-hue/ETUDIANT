import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // pdfjs-dist référence "canvas" (optionnel, Node-only) — on l'alias à un module vide.
  turbopack: {
    resolveAlias: {
      canvas: "./src/lib/empty-module.ts",
    },
  },
};

export default nextConfig;
